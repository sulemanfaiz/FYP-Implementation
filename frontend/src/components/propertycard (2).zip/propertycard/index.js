export { default } from "./propertycard";
